# euro-bill > 2023-03-24 10:53am
https://universe.roboflow.com/object-detection/euro-bill

Provided by a Roboflow user
License: Public Domain

